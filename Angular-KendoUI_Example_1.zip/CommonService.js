'use strict;'

angular.module('ExampleModule').factory('CommonService', CommonService);

function CommonService (CommonClient) {
  
  
    return{
      getCities: function(){ 
        return CommonClient.GetCities().query();
      },
      getUsers: function(){
        return CommonClient.GetUsers().query();
      }
      
    }
}