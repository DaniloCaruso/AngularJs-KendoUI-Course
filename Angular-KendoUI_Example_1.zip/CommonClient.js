'use strict;'

angular.module('ExampleModule').factory('CommonClient', CommonClient);

function CommonClient ($resource) {
  
  this.CommonClient = {
    GetCities : GetCities,
    GetUsers: GetUsers
    
  };
  
  return this.CommonClient;
  
  //CORS enabled by Mocky.io with extra header:
  //Access-Control-Allow-Origin:http://run.plnkr.co
  function GetCities(){
    return $resource("Cities.json" , {} , {});
  }
  
    function GetUsers(){
    return $resource("Users.json" , {} , {});
  }
    
}
