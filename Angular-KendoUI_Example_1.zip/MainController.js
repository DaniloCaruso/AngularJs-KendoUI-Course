angular.module('ExampleModule').controller('MainController', MainController);


function MainController(CommonService) {
  
  var that = this;
  
  
  /*USERS GRID CONF*/ 
  this.user;
  this.users = CommonService.getUsers();

  this.usersDatasource = new kendo.data.DataSource({
    transport: {
        read: function (options) {
            that.users.$promise.then(function () {
                options.success(that.users);
            });
        }
    }
  });
  
  this.usersOptions = {
    dataSource: this.usersDatasource,
    selectable:"row",
    height: 400,
    scrollable:true,
    columns:
        [
          { field: "name"     ,  title:"Name" },
          { field: "surname"  ,  title:"Surname"},
          { field: "age"      ,  title:"Age" },
          { field: "email"    ,  title:"Email" }
        ],
};

this.selectUser = function(dataItem){
  this.user = dataItem;
}

}