	angular.module('ExampleUtility').provider('CommonApplicationSettingsService',  function( $translatePartialLoaderProvider, $translateProvider) {


	this.setupTranslateProvider = function(culture) {
		    var basePath = "";
        this.culture = culture;
        
		    $translatePartialLoaderProvider.addPart('/');
        $translateProvider.useLoader('$translatePartialLoader', {
          urlTemplate: basePath+'Strings.{lang}.json'
        });

        $translateProvider.preferredLanguage(this.culture);
		    $translateProvider.use(this.culture);
        kendo.culture(this.culture);
    };

    this.$get = function($translate) {
        var culture = this.culture;
        //var kendoMessagesToBeLoaded = true;
        return {
        setCultureName: function (culture) {

				  this.culture = culture;
				
					$translate.use(this.culture);
					$translate.preferredLanguage(this.culture);
					$translate.use(this.culture);
					kendo.culture(this.culture);
				
                //if (kendoMessagesToBeLoaded) {
                $.getScript("http://kendo.cdn.telerik.com/2016.2.607/js/messages/kendo.messages."+ this.culture +".min.js");
               // kendoMessagesToBeLoaded = false;
              //}
            }
        };
    };

});