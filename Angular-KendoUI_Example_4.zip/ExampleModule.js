angular.module('ExampleModule' , ['ngResource' , 'kendo.directives' , 'pascalprecht.translate' , 'ExampleUtility'])
  .config(['CommonApplicationSettingsServiceProvider', function(CommonApplicationSettingsServiceProvider) {
    CommonApplicationSettingsServiceProvider.setupTranslateProvider('it-IT');

    }])
  .run(function(CommonApplicationSettingsService) {
     CommonApplicationSettingsService.setCultureName('it-IT');
  });