function User() {
  this.id,
    this.name = "";
  this.surname = "";
  this.age = null;
  this.gender = "";
  this.company = "";
  this.email = "";
  this.phone = "";
  this.address = "";
  this.city = {
    id: null,
    name: ""
  };
  this.greeting = "";
}

angular.module('ExampleModule').controller('MainController', MainController);


function MainController(CommonService,$timeout,$translate,CommonApplicationSettingsService,$scope) {

  var that = this;
  this.usersGrid;
  this.usersOptions;
  this.user;
  this.userBackup;
  this.selectUser;
  this.clearUser;
  this.readOnly = false;
  this.fromCreateNew = false;
  this.fromEdit;
  this.users = CommonService.getUsers();
  this.cities = CommonService.getCities();
  this.citiesDataSource;
  this.citiesOptions;
  this.userModifyForm;
  this.translate=$translate;
  this.CommonApplicationSettingsService = CommonApplicationSettingsService;
  this.scope = $scope;
  this.calendarOptions = {
    culture:this.translate.use()
  };
  //this.CommonApplicationSettingsService.setCultureName("it-IT");
  
  this.scope.$watch(
                function(){
                    return that.translate.use()
                }, function(val){
                  
                  that.calendarComponent.setOptions({culture:val});
                  
                });


  /*USERS GRID CONF*/
  this.usersDatasource = new kendo.data.DataSource({
    transport: {
      read: function(options) {
        that.users.$promise.then(function() {
          options.success(that.users);
        });
      }
    }
  });

  this.usersOptions = {
    dataSource: this.usersDatasource,
    selectable: "row",
    height: 200,
    scrollable: true,
    columns: [{
      field: "name",
      title: "{{'name' | translate}}"
    }, {
      field: "surname",
      title: "{{'surname' | translate}}"
    }, {
      field: "age",
      title: "{{'age' | translate}}"
    }, {
      field: "email",
      title: "{{'email' | translate}}"
    }, {
      field: "city.name",
      title: "{{'city' | translate}}"
    }]
  }


  this.selectUser = function(dataItem) {
    that.user = dataItem;
    if (that.user) {
      that.userBackup = angular.copy(that.user);
    }
    that.readOnly = true;
    that.fromCreateNew = false;
    that.fromEdit = false;
  };

  that.editUser = function() {
    that.readOnly = false;
    that.fromEdit = true;
    that.fromCreateNew = false;
  }

  this.clearUser = function() {
    angular.copy(that.userBackup, that.user);
    that.usersGrid.clearSelection();
    that.readOnly = true;
    that.fromCreateNew = false;
    that.fromEdit = false;
  };

  that.createNewUser = function() {
    that.user = new User();
    that.readOnly = false;
    that.fromCreateNew = true;
    that.fromEdit = false;
  }

  this.setReadOnlyAndResetView = function() {
    that.readOnly = true;
    that.fromCreateNew = false;
    that.fromEdit = false;
  }

  this.addUserAndResetView = function() {
    
    that.user.id = that.getLastId();
    that.usersGrid.dataSource.add(that.user);
    that.readOnly = false;
    that.fromCreateNew = false;
    that.fromEdit = false;
    angular.copy(that.userBackup, that.user);
  }

  this.toggleReadOnly = function() {
    that.readOnly = !that.readOnly;
  };

  this.cancel= function(){
    that.readOnly = true;
    that.fromCreateNew = false;
    that.fromEdit = false;
    angular.copy(that.userBackup, that.user);
  }

  this.getLastId= function(){
    var allUsersId = that.usersGrid.dataSource.data().map(function(data){
      return data.id;
    });
    allUsersId.sort(function (a, b) {  return a - b;  });
    var maxId = allUsersId[allUsersId.length-1]+1;
    return maxId;
  }
  

  /*CITIES CONF*/
  this.citiesDataSource = {
    pageSize: 20,
    transport: {
      read: function(options) {
        that.cities.$promise.then(function() {
          options.success(that.cities);
        });
      }
    }
  };

  this.citiesOptions = {
    dataTextField:  "name",
    dataValueField: "id", 
    virtual: {
      itemHeight: 26,
      valueMapper: function(options) {
        options.success([options.value || 0]); 
      }
    },
    height: 200,
    dataSource: this.citiesDataSource,
    valuePrimitive: false,
    filter: "startswith"
  };


  /*GENDER CONF*/
  
  this.genderDataSource = [
    {
      gender:'M',
    },
    {
      gender:'F',
    }
  ];

  this.genderOptions = {
    dataTextField: "gender",
    dataValueField: "gender",
    dataSource:this.genderDataSource,
    valuePrimitive: false,
    filter: "startswith"
  };
  
  

}