'use strict;'

angular.module('ExampleModule').factory('KendoUtilityService', KendoUtilityService);

function KendoUtilityService() {

  this.setFields= function(rawDataSource, otherOptions) {
    Object.getOwnPropertyNames(otherOptions).forEach(function(field) {
      rawDataSource[field] = otherOptions[field];
    });
  }

  return {
    getDataSourceFromPromise: function(sourceData, otherOptions) {

      var rawDataSource = {
        transport: {
          read: function(options) {
            sourceData.$promise.then(function() {
              options.success(sourceData);
            });
          }
        }
      };

      if (otherOptions) {
        addFieldsToConfig(rawDataSource, otherOptions)
      }

      var datasource = new kendo.data.DataSource(rawDataSource);
      return datasource;
    }
  },

  getDataSourceFromArray: function(sourceData, otherOptions) {
      var rawDataSource = {
        data: sourceData
      };
      if (otherOptions) {
        addFieldsToConfig(rawDataSource, otherOptions)
      }
      return new kendo.data.DataSource(rawDataSource);
    },

    getDataSourceFromObservableArray: function(sourceData, otherOptions) {
      var rawDataSource = {
        data: sourceData
      });

  if (otherOptions) {
    addFieldsToConfig(rawDataSource, otherOptions)
  }

  return new kendo.data.DataSource(rawDataSource);
},

getComboBoxOptions: function(dataSource, otherOptions) {
    var options = {
      dataSource: dataSource,
      dataTextField: "description",
      dataValueField: "id",
      filter: "contains"
    };
    if (otherOptions) {
      addFieldsToConfig(options, otherOptions);
    };
    return options;
  },

  getGridOptions: function(dataSource, otherOptions) {
    var options = {
      dataSource: datasource,
      selectable: 'row',
      scrollable: true,
    };
    if (otherOptions) {
      addFieldsToConfig(options, otherOptions);
    };
    return options;
  }

}