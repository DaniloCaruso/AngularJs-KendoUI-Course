'use strict;'

angular.module('ExampleModule').factory('CommonClient', CommonClient);

function CommonClient ($resource) {
  
  this.CommonClient = {
    GetCities : GetCities,
    GetUsers: GetUsers
    
  };
  
  return this.CommonClient;
  

  function GetCities(){
    return $resource("Cities.json" , {} , {});
  }
  
    function GetUsers(){
    return $resource("Users.json" , {} , {});
  }
  
}
